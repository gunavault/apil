<?php

namespace App\Http\Controllers;

use App\Grade;
use Illuminate\Http\Request;

class GradeController extends Controller{
//    kondisi di update dan delete belum ditambahin
//     1. kalau id nya tidak ditemukan
//     2. kalau parameter nya kosong
//     3. kalau ada error jaringan / server


    private $defaultplasma = array("SGH", "SBT", "TPU", "STA");
    private $defaultkebun = array("SGH","SPA","SGO", "SBT","LDA", "TPU","TME", "STA", "SIN", "TER");

    public function index()
    {
        $grade = Grade::all();

        $geoJSON = [];
        $geoJSON['type']='FeatureCollection';
        foreach($grade as $p){
            $data = [
                    'grade'=>$p->grade,
                    'unit'=>$p->unit,
                    'jenis'=>$p->jenis,
                    'tenera_min'=>$p->tenera_min,
                    'tenera_max'=>$p->tenera_max,
                    'dura_min'=>$p->dura_min,
                    'dura_max'=>$p->dura_max
            ];
            $geoJSON['features'][]=$data;
            //untuk filter
            $geoJSON['filterPlasma']=$this->defaultplasma;
            $geoJSON['filterkebun']=$this->defaultkebun;
        }
        return response()->json($geoJSON);
    }

    public function update(Request $request,$id)
    {
        //alur nya gini
        //1. grade lama di update status nya jadi NONAKTIF
        //2. grade yang diubah di insert jadi status nya AKTIF

        $grade = Grade::find($id);
        $grade->grade = $request->grade;
        $grade->unit = $request->unit;
        $grade->jenis = $request->jenis;
        $grade->tenera_min = $request->tenera_min;
        $grade->tenera_max = $request->tenera_max;
        $grade->dura_min = $request->dura_min;
        $grade->dura_max = $request->dura_max;
        $grade->save();
        return [
            "sukses"=>true,
            "data"=>$grade,
        ];
    }

    public function delete($id)
    {
        $grade = Grade::find($id);
        $grade->delete();
        return [
            "sukses"=>true
        ];
    }
}
