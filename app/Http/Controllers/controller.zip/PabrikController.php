<?php

namespace App\Http\Controllers;

use App\Pabrik;
use App\SortasiPlasma;

class PabrikController extends Controller{
    private $defaultplasma = array("SGH", "SBT", "TPU", "STA");
    private $defaultkebun = array("SGH","SPA","SGO", "SBT","LDA", "TPU","TME", "STA", "SIN", "TER");

    public function index()
    {
        $pabrik = Pabrik::withCount(['sortasiPlasma'=>function($s){
            $s->orderBy('grade','asc');
        }])->get();
        $trip_new = SortasiPlasma::where('status', '1')->orwhere('status', '2')->where('tanggal', '2022-08-15')->take(10)->orderBy('masuk', 'asc')->get();
        $nettoToday = SortasiPlasma::where('status', '1')->orwhere('status', '2')->where('tanggal', '2022-08-15')->sum('netto');
        $nettoLastDay = SortasiPlasma::where('status', '1')->orwhere('status', '2')->where('tanggal', '2022-08-15')->sum('netto');
//        dump($nettoToday);
//        dump($nettoLastDay);
        $pabrik->load('sortasiPlasma');

        //p adalah representasi pabrik
        $pabrik->transform(function($p){
            $p->grade_group = $p->sortasiPlasma->groupBy('grade');
            $p->grade_group->transform(function($g, $nama){
                if($nama ==""){
                    $nama ="Proses Grading";
                }
                return [
                    'grade_name'=>$nama,
                    'count'=>$g->count(),
                    'sum_netto'=>$g->sum('netto'),
                    'sum_brutto'=>$g->sum('bruto')
                ];
            });
            $p->grade_group = array_values($p->grade_group->toArray());
            return $p;
        });
        $geoJSON = [];
        $geoJSON['type']='FeatureCollection';
        foreach($pabrik as $p){
            $data = [
                'type' => 'Feature',
                'properties'=> [
                    'nama'=>$p->nama,
                    'unit'=>$p->unit,
                    'grade'=> $p->grade_group,//->toArray(),
                ]
                ,
                'geometry'=>[
                    'type'=>'Point',
                    'coordinates'=>[$p->lat,$p->long]
                ],
            ];
            $geoJSON['features'][]=$data;
            $geoJSON['tripnew']=$trip_new;
            $geoJSON['nettoToday']=$nettoToday;
            $geoJSON['nettoLastDay']=$nettoLastDay;

            //untuk filter
            $geoJSON['filterPlasma']=$this->defaultplasma;
            $geoJSON['filterkebun']=$this->defaultkebun;
        }
        return response()->json($geoJSON);
    }
}
