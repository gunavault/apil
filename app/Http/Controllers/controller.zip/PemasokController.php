<?php

namespace App\Http\Controllers;

use App\Pemasok;
use Illuminate\Http\Request;

class PemasokController extends Controller{

//    kondisi di update dan delete belum ditambahin
//     1. kalau id nya tidak ditemukan
//     2. kalau parameter nya kosong
//     3. kalau ada error jaringan / server

    private $defaultplasma = array("SGH", "SBT", "TPU", "STA");
    private $defaultkebun = array("SGH","SPA","SGO", "SBT","LDA", "TPU","TME", "STA", "SIN", "TER");

    public function index()
    {
        $pemasok = Pemasok::all();
//        return response()->json($pemasok);
        $geoJSON = [];
        $geoJSON['type']='FeatureCollection';
        foreach($pemasok as $p){
            $data = [
                    'nama'=>$p->nama,
                    'unit'=>$p->unit,
                    'jenis'=>$p->jenis,
                    'plasma'=>$p->plasma,
                    'suppliercode'=>$p->suppliercode,
                    'on_create'=>$p->on_create,
                    'created_by'=>$p->created_by
            ];
            $geoJSON['features'][]=$data;
            //untuk filter
            $geoJSON['filterPlasma']=$this->defaultplasma;
            $geoJSON['filterkebun']=$this->defaultkebun;
        }
        return response()->json($geoJSON);
    }

    public function update(Request $request,$id)
    {
        $pemasok = Pemasok::find($id);
        $pemasok->nama = $request->nama;
        $pemasok->save();
        return [
            "sukses"=>true,
            "data"=>$pemasok,
        ];
    }

    public function delete($id)
    {
        $pemasok = Pemasok::find($id);
        $pemasok->delete();
        return [
            "sukses"=>true
        ];
    }
}
