<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class Pabrik extends Model
{
    protected $table = 'pabrik';
    public $timestamps = false;

    public function sortasiPlasma(){
        return $this->hasMany(SortasiPlasma::class, 'kode_kebun', 'unit');
    }
}
